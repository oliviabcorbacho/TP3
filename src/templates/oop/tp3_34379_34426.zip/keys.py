import msvcrt
import random
from re import X

def read_single_keypress():
            key= msvcrt.getch().decode('UTF-8')
            return key





